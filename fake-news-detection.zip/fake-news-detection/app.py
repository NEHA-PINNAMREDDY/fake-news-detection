import streamlit as st
import pickle
from utils import preprocess_text

# Load the saved model and vectorizer
model = pickle.load(open('fake-news-detection/fake_news_model.pkl', 'rb'))
vectorizer = pickle.load(open('fake-news-detection/vectorizer.pkl', 'rb'))

st.title("📰 Fake News Detection")

input_text = st.text_area("Enter news article text below:")

if st.button("Predict"):
    if input_text.strip() == "":
        st.warning("Please enter some text.")
    else:
        preprocessed = preprocess_text(input_text)
        vectorized = vectorizer.transform([preprocessed])
        prediction = model.predict(vectorized)[0]
        if prediction == 1:
            st.success("✅ This news appears to be REAL.")
        else:
            st.error("❌ This news appears to be FAKE.")